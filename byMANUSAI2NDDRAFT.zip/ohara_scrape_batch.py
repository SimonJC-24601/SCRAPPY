import { chromium } from 'playwright';
import fs from 'fs';
import path from 'path';
import JSZip from 'jszip';

const sessionPath = './user-data';
const appUrls = [
  "https://ohara.ai/mini-apps/25fa2628-466f-4975-9b82-affb779a5183/build"
  "https://ohara.ai/mini-apps/2301fb68-b61a-4a19-8339-c0ccb6a2fa0b/build",
  "https://ohara.ai/mini-apps/3c4c4873-360d-4a9d-9aad-0470749955bb/build",
  "https://ohara.ai/mini-apps/94c886ef-27a7-42b4-97b2-6f51e030ebe9/build",
  "https://ohara.ai/mini-apps/2e17ca0b-9d62-4bef-bc8d-780c9cd79258/build",
  "https://ohara.ai/mini-apps/f12f5b1e-9f6d-4a37-8a78-eebcd000c0e6/build",
  "https://ohara.ai/mini-apps/3dc63db7-3732-4eae-9c56-454d86673faa/build",
  "https://ohara.ai/mini-apps/cbe5f7c0-ff4e-47f4-a9ff-00550735da47/build",
  "https://ohara.ai/mini-apps/9b1ceb1d-eaf3-406d-a6b5-6d822d3d9113/build",
  "https://ohara.ai/mini-apps/700942a3-7c4f-4f9b-bba5-113279880eeb/build",
  "https://ohara.ai/mini-apps/f1834b91-7dc7-4d8d-a9c6-ae3a308ea6f4/build",
  "https://ohara.ai/mini-apps/8ecffcd6-68f7-423c-aac1-0cc96296a69d/build",
  "https://ohara.ai/mini-apps/3fd77fea-3d6e-420a-85ab-0516d75e9c57/build",
  "https://ohara.ai/mini-apps/575016a2-1661-469c-807d-d7052197530f/build",
  "https://ohara.ai/mini-apps/95b06150-eb25-476f-80f6-d3ddb638d203/build",
  "https://ohara.ai/mini-apps/7a560421-a7af-47b7-85fb-5ea09d6108ba/build",
  "https://ohara.ai/mini-apps/e6da0ba9-12d5-4cff-8ef0-6ce663b66e34/build",
  "https://ohara.ai/mini-apps/789da2e0-991c-4bec-96d2-54a763989670/build",
  "https://ohara.ai/mini-apps/a8864c7f-49f3-424d-b549-e7be0f9fff01/build",
  "https://ohara.ai/mini-apps/6737fd16-ae70-499d-9db0-2e1ddd2df7f4/build",,
  // ... add the rest here
];

// Check if session folder exists and has content
function isSessionReady(sessionDir: string): boolean {
  try {
    const files = fs.readdirSync(sessionDir);
    return files.length > 0;
  } catch {
    return false;
  }
}

(async () => {
  if (!isSessionReady(sessionPath)) {
    console.warn(`⚠️ Session folder "${sessionPath}" is missing or empty.`);
    console.warn(`🛑 Please log in manually when the browser opens.`);
  }

  const browser = await chromium.launchPersistentContext(sessionPath, {
    headless: false,
  });
  const page = await browser.newPage();

  // Wait for login confirmation (e.g., dashboard or known element)
  await page.goto('https://ohara.ai/');
  try {
    await page.waitForSelector('[data-sentry-component="Sidebar"]', { timeout: 15000 });
    console.log('✅ Session confirmed. Proceeding with scraping...');
  } catch {
    console.error('❌ Login not detected. Please log in and restart the script.');
    await browser.close();
    return;
  }

  const zip = new JSZip();

  for (const url of appUrls) {
    console.log(`🔍 Visiting: ${url}`);
    await page.goto(url);
    await page.waitForSelector('[data-sentry-component="CodeTab"]');

    const tabs = await page.$$('[data-sentry-component="CodeTab"]');

    for (let i = 0; i < tabs.length; i++) {
      const tab = tabs[i];
      await tab.click();
      await page.waitForTimeout(500);

      const filename = await tab.$eval('span', el => el.textContent?.trim() || `file-${i}.ts`);
      const code = await page.$eval('[data-sentry-component="SimpleCodeEditor"]', el => el.innerText);

      const slug = url.split('/')[4];
      const filePath = `${slug}/${filename}`;
      zip.file(filePath, code);
      console.log(`✅ Scraped: ${filePath}`);
    }
  }

  const zipBuffer = await zip.generateAsync({ type: 'nodebuffer' });
  const outputPath = path.join(__dirname, 'ohara-code.zip');
  fs.writeFileSync(outputPath, zipBuffer);

  console.log(`🎉 Exported all apps to ${outputPath}`);
  await browser.close();
})();

