import fs from 'fs';
import path from 'path';
import { chromium } from 'playwright';
import { parse } from 'url';

const OUTPUT_DIR = './My_App_Design_Source_Code';
const MAX_RETRIES = 5;

interface ScrapeResult {
  url: string;
  components: string[];
  screenshot: string;
  log: string[];
}

function slugify(url: string): string {
  const { hostname, pathname } = parse(url);
  return `${hostname}${pathname}`.replace(/[^a-zA-Z0-9]/g, '_');
}

function logLore(message: string, loreEnabled: boolean): string {
  const timestamp = new Date().toISOString();
  const cheeky = loreEnabled ? `🧙‍♂️ ${message}` : message;
  return `[${timestamp}] ${cheeky}`;
}

async function scrapeUrl(url: string, loreEnabled: boolean): Promise<ScrapeResult | null> {
  const log: string[] = [];
  for (let attempt = 1; attempt <= MAX_RETRIES; attempt++) {
    try {
      log.push(logLore(`Attempt ${attempt} to scrape ${url}`, loreEnabled));
      const browser = await chromium.launch({ headless: true });
      const page = await browser.newPage();
      await page.goto(url, { timeout: 30000 });

      const components = await page.$$eval('[data-component]', els =>
        els.map(el => el.getAttribute('data-component') || '')
      );

      const slug = slugify(url);
      const screenshotPath = path.join(OUTPUT_DIR, `${slug}.png`);
      await page.screenshot({ path: screenshotPath });

      await browser.close();

      log.push(logLore(`Scraped ${components.length} components from ${url}`, loreEnabled));
      log.push(logLore(`Screenshot saved to ${screenshotPath}`, loreEnabled));

      return {
        url,
        components,
        screenshot: path.basename(screenshotPath),
        log,
      };
    } catch (error) {
      log.push(logLore(`Error on attempt ${attempt}: ${error}`, loreEnabled));
      if (attempt === MAX_RETRIES) {
        log.push(logLore(`Failed to scrape ${url} after ${MAX_RETRIES} attempts`, loreEnabled));
        return null;
      }
    }
  }
  return null;
}

async function main() {
  const urls = [
    'https://ohara.dev/components/button',
    'https://ohara.dev/components/input',
    // Add more URLs here
  ];

  const loreEnabled = process.argv.includes('--lore');

  for (const url of urls) {
    const result = await scrapeUrl(url, loreEnabled);
    if (result) {
      const outputPath = path.join(OUTPUT_DIR, `${slugify(url)}.json`);
      fs.writeFileSync(outputPath, JSON.stringify(result, null, 2));
      console.log(logLore(`✅ Saved scrape result to ${outputPath}`, loreEnabled));
    } else {
      console.log(logLore(`❌ Skipped ${url} due to repeated failures`, loreEnabled));
    }
  }
}

main();
