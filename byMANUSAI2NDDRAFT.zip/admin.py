from flask import Blueprint, jsonify, request, session
from datetime import datetime
from src.models.admin_user import AdminUser, db
from src.models.scraped_data import ScrapedData
from src.models.site_content import SiteContent

admin_bp = Blueprint('admin', __name__)

def require_admin():
    """Check if user is logged in as admin"""
    if 'admin_user_id' not in session:
        return jsonify({'error': 'Authentication required'}), 401
    return None

@admin_bp.route('/admin/login', methods=['POST'])
def admin_login():
    """Admin login endpoint"""
    data = request.json
    username = data.get('username')
    password = data.get('password')
    
    if not username or not password:
        return jsonify({'error': 'Username and password required'}), 400
    
    admin_user = AdminUser.query.filter_by(username=username).first()
    
    if admin_user and admin_user.check_password(password):
        session['admin_user_id'] = admin_user.id
        admin_user.last_login = datetime.utcnow()
        db.session.commit()
        
        return jsonify({
            'message': 'Login successful',
            'user': admin_user.to_dict()
        })
    else:
        return jsonify({'error': 'Invalid credentials'}), 401

@admin_bp.route('/admin/logout', methods=['POST'])
def admin_logout():
    """Admin logout endpoint"""
    session.pop('admin_user_id', None)
    return jsonify({'message': 'Logout successful'})

@admin_bp.route('/admin/me', methods=['GET'])
def admin_me():
    """Get current admin user info"""
    auth_error = require_admin()
    if auth_error:
        return auth_error
    
    admin_user = AdminUser.query.get(session['admin_user_id'])
    return jsonify(admin_user.to_dict())

@admin_bp.route('/admin/scraped-data', methods=['GET'])
def admin_get_scraped_data():
    """Admin view of scraped data with management capabilities"""
    auth_error = require_admin()
    if auth_error:
        return auth_error
    
    page = request.args.get('page', 1, type=int)
    per_page = request.args.get('per_page', 20, type=int)
    
    scraped_data = ScrapedData.query.order_by(ScrapedData.timestamp.desc()).paginate(
        page=page, 
        per_page=per_page, 
        error_out=False
    )
    
    return jsonify({
        'data': [item.to_dict() for item in scraped_data.items],
        'total': scraped_data.total,
        'pages': scraped_data.pages,
        'current_page': page,
        'per_page': per_page
    })

@admin_bp.route('/admin/scraped-data/<int:data_id>', methods=['DELETE'])
def admin_delete_scraped_data(data_id):
    """Delete scraped data entry"""
    auth_error = require_admin()
    if auth_error:
        return auth_error
    
    data = ScrapedData.query.get_or_404(data_id)
    db.session.delete(data)
    db.session.commit()
    
    return jsonify({'message': 'Scraped data deleted successfully'})

@admin_bp.route('/admin/users', methods=['GET'])
def admin_get_users():
    """Get all admin users"""
    auth_error = require_admin()
    if auth_error:
        return auth_error
    
    users = AdminUser.query.all()
    return jsonify([user.to_dict() for user in users])

@admin_bp.route('/admin/users', methods=['POST'])
def admin_create_user():
    """Create new admin user"""
    auth_error = require_admin()
    if auth_error:
        return auth_error
    
    data = request.json
    username = data.get('username')
    password = data.get('password')
    role = data.get('role', 'admin')
    
    if not username or not password:
        return jsonify({'error': 'Username and password required'}), 400
    
    # Check if username already exists
    existing_user = AdminUser.query.filter_by(username=username).first()
    if existing_user:
        return jsonify({'error': 'Username already exists'}), 400
    
    admin_user = AdminUser(username=username, role=role)
    admin_user.set_password(password)
    
    db.session.add(admin_user)
    db.session.commit()
    
    return jsonify(admin_user.to_dict()), 201

@admin_bp.route('/admin/users/<int:user_id>', methods=['DELETE'])
def admin_delete_user(user_id):
    """Delete admin user"""
    auth_error = require_admin()
    if auth_error:
        return auth_error
    
    # Prevent deleting self
    if user_id == session['admin_user_id']:
        return jsonify({'error': 'Cannot delete your own account'}), 400
    
    user = AdminUser.query.get_or_404(user_id)
    db.session.delete(user)
    db.session.commit()
    
    return jsonify({'message': 'User deleted successfully'})

@admin_bp.route('/admin/analytics', methods=['GET'])
def admin_analytics():
    """Get analytics data"""
    auth_error = require_admin()
    if auth_error:
        return auth_error
    
    total_scraped = ScrapedData.query.count()
    total_admins = AdminUser.query.count()
    total_content_sections = SiteContent.query.count()
    
    # Recent activity (last 7 days)
    from datetime import datetime, timedelta
    week_ago = datetime.utcnow() - timedelta(days=7)
    recent_scrapes = ScrapedData.query.filter(ScrapedData.timestamp >= week_ago).count()
    
    return jsonify({
        'total_scraped_items': total_scraped,
        'total_admin_users': total_admins,
        'total_content_sections': total_content_sections,
        'recent_scrapes_7_days': recent_scrapes
    })

