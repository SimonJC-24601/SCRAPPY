from flask import Blueprint, jsonify, request, session
from src.models.site_content import SiteContent, db

site_content_bp = Blueprint('site_content', __name__)

def require_admin():
    """Check if user is logged in as admin"""
    if 'admin_user_id' not in session:
        return jsonify({'error': 'Authentication required'}), 401
    return None

@site_content_bp.route('/site-content/<page_name>', methods=['GET'])
def get_site_content(page_name):
    """Get all content for a specific page (public endpoint)"""
    content_items = SiteContent.query.filter_by(page_name=page_name).all()
    
    # Organize content by section_id
    content_dict = {}
    for item in content_items:
        content_dict[item.section_id] = {
            'content': item.content,
            'content_type': item.content_type,
            'last_updated': item.last_updated.isoformat() if item.last_updated else None
        }
    
    return jsonify({
        'page_name': page_name,
        'sections': content_dict
    })

@site_content_bp.route('/site-content/<page_name>/<section_id>', methods=['GET'])
def get_site_content_section(page_name, section_id):
    """Get specific section content (public endpoint)"""
    content = SiteContent.query.filter_by(page_name=page_name, section_id=section_id).first()
    
    if not content:
        return jsonify({'error': 'Content not found'}), 404
    
    return jsonify(content.to_dict())

@site_content_bp.route('/admin/site-content', methods=['GET'])
def admin_get_all_content():
    """Get all site content for admin management"""
    auth_error = require_admin()
    if auth_error:
        return auth_error
    
    page = request.args.get('page', 1, type=int)
    per_page = request.args.get('per_page', 20, type=int)
    
    content_items = SiteContent.query.order_by(SiteContent.last_updated.desc()).paginate(
        page=page, 
        per_page=per_page, 
        error_out=False
    )
    
    return jsonify({
        'data': [item.to_dict() for item in content_items.items],
        'total': content_items.total,
        'pages': content_items.pages,
        'current_page': page,
        'per_page': per_page
    })

@site_content_bp.route('/admin/site-content', methods=['POST'])
def admin_create_content():
    """Create new site content"""
    auth_error = require_admin()
    if auth_error:
        return auth_error
    
    data = request.json
    page_name = data.get('page_name')
    section_id = data.get('section_id')
    content = data.get('content')
    content_type = data.get('content_type', 'text')
    
    if not page_name or not section_id or not content:
        return jsonify({'error': 'page_name, section_id, and content are required'}), 400
    
    # Check if content already exists
    existing_content = SiteContent.query.filter_by(page_name=page_name, section_id=section_id).first()
    if existing_content:
        return jsonify({'error': 'Content for this page and section already exists. Use PUT to update.'}), 400
    
    site_content = SiteContent(
        page_name=page_name,
        section_id=section_id,
        content=content,
        content_type=content_type,
        updated_by=session['admin_user_id']
    )
    
    db.session.add(site_content)
    db.session.commit()
    
    return jsonify(site_content.to_dict()), 201

@site_content_bp.route('/admin/site-content/<int:content_id>', methods=['PUT'])
def admin_update_content(content_id):
    """Update existing site content"""
    auth_error = require_admin()
    if auth_error:
        return auth_error
    
    content_item = SiteContent.query.get_or_404(content_id)
    data = request.json
    
    content_item.content = data.get('content', content_item.content)
    content_item.content_type = data.get('content_type', content_item.content_type)
    content_item.updated_by = session['admin_user_id']
    content_item.last_updated = db.func.now()
    
    db.session.commit()
    
    return jsonify(content_item.to_dict())

@site_content_bp.route('/admin/site-content/<int:content_id>', methods=['DELETE'])
def admin_delete_content(content_id):
    """Delete site content"""
    auth_error = require_admin()
    if auth_error:
        return auth_error
    
    content_item = SiteContent.query.get_or_404(content_id)
    db.session.delete(content_item)
    db.session.commit()
    
    return jsonify({'message': 'Content deleted successfully'})

